'use client';

import React from 'react';
import ChatIAModule from '@/modules/chat/ChatIAModule';

export default function Chat() {
  return <ChatIAModule />;
}
