'use client';

import React from 'react';
import TendenciasModule from '@/modules/graficos/Tendencias';

export default function Tendencias() {
  return <TendenciasModule />;
}
